package com.m.mvp.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;

import com.m.mvp.R;
import com.m.mvp.logic.CheckBookRowFactory;
import com.m.mvp.presenter.CheckBookPresenter;
import com.m.mvp.presenter.UsePresenter;

import java.util.LinkedList;

/**
 * Created by test on 7/1/15.
 */
@UsePresenter(CheckBookPresenter.class)
public class CheckBookFragment extends CoreFragment implements CheckBookPresenter.Delegate {

    CheckBookRowFactory mFactory;
    TableLayout checkLayout;

    public static CheckBookFragment getNewInstance(Bundle args) {
        CheckBookFragment mInstance = new CheckBookFragment();
        mInstance.setArguments(args);
        return mInstance;

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_checkbook, container, false);
        //DO YOUR INITIALIZATION HERE
        mFactory = new CheckBookRowFactory(getActivity());
        checkLayout = (TableLayout) rootView.findViewById(R.id.table_check_book);
        return rootView;
    }


    @Override
    public void loadCheckBookScreen() {
        Button addNewRow = (Button) findViewById(R.id.table_add_new_row);
        addNewRow.setOnClickListener(addNewRowListener);
        mFactory.makeHeaderRow(checkLayout);
    }

    private View.OnClickListener saveRowListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

        }
    };

    private View.OnClickListener addNewRowListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            mFactory.makeRow(checkLayout);
        }
    };
}
