package com.m.mvp.presenter;

/**
 */
public class CheckBookPresenter  extends CorePresenter<CheckBookPresenter.Delegate> {


    public interface Delegate{
        void loadCheckBookScreen();
    }

    @Override
    public void onTakeView(Delegate delegate) {
        super.onTakeView(delegate);
        delegate.loadCheckBookScreen();
    }



}
