package com.m.mvp.logic;

import android.content.Context;
import android.widget.TableLayout;

import java.util.LinkedList;

/**
 *
 */
public interface TableRowFactory {
    void makeRow(TableLayout parentLayout);
    TableRowFactory makeHeaderRow(TableLayout parentLayout);
}
