package com.m.mvp.logic;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.m.mvp.R;
import com.m.mvp.model.Row;
import com.m.mvp.widgets.DatePickerEditText;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by test on 7/3/15.
 */
public class CheckBookRowFactory implements TableRowFactory {


    private Context mContext;
    private TableRow.LayoutParams mTableRowLayoutParams = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT);
    private static final int HEADER_TEXT_COLOR = Color.BLACK;
    private CheckBookRowTemplate rowTemplate;

    public CheckBookRowFactory(Context context) {
        this.rowTemplate = new CheckBookRowTemplate();
        this.mContext = context;
    }

    @Override
    public void makeRow(TableLayout parentLayout) {
        Row mRow = new Row();
        TableRow row = new TableRow(mContext);
        LinkedHashMap<String, TableRow.LayoutParams> listHeader = rowTemplate.generateTemplate(mContext);
        int padding = rowTemplate.padding;
        row.setLayoutParams(mTableRowLayoutParams);
        for (Map.Entry<String, TableRow.LayoutParams> entry : listHeader.entrySet()) {
            String key = entry.getKey();
            TableRow.LayoutParams value = entry.getValue();
            row.addView(configRow(key, value));
        }
        row.startAnimation(AnimationUtils.loadAnimation(mContext, android.R.anim.fade_in));
        parentLayout.addView(row);

    }

    private View configRow(String key, TableRow.LayoutParams value) {
        EditText mEditText = new EditText(mContext);
        mEditText.setSingleLine(true);
        mEditText.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.table_border));
        mEditText.setLayoutParams(value);

        if (CheckBookRowTemplate.HEADER_X.equalsIgnoreCase(key)) {
            return mEditText;

        } else if (CheckBookRowTemplate.HEADER_DATE.equalsIgnoreCase(key)) {
            DatePickerEditText mDatePickerEditText = new DatePickerEditText(mContext);
            mDatePickerEditText.setSingleLine(true);
            mDatePickerEditText.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.table_border));
            mDatePickerEditText.setLayoutParams(value);
            return mDatePickerEditText;

        } else if (CheckBookRowTemplate.HEADER_CHECK_NO.equalsIgnoreCase(key)) {
            return mEditText;
        } else if (CheckBookRowTemplate.HEADER_TRANSACTION.equalsIgnoreCase(key)) {
            return mEditText;
        } else if (CheckBookRowTemplate.HEADER_CREDIT.equalsIgnoreCase(key)) {
            mEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
            return mEditText;

        } else if (CheckBookRowTemplate.HEADER_DEBIT.equalsIgnoreCase(key)) {
            mEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
            return mEditText;

        } else if (CheckBookRowTemplate.HEADER_BALANCE.equalsIgnoreCase(key)) {
            mEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
            return mEditText;
        } else {
            return mEditText;
        }
    }


    @Override
    public CheckBookRowFactory makeHeaderRow(TableLayout parentLayout) {
        if (parentLayout == null) {
            throw new RuntimeException("Header or parent layout cannot be null");
        }
        TableRow row = new TableRow(mContext);
        LinkedHashMap<String, TableRow.LayoutParams> listHeader = rowTemplate.generateTemplate(mContext);
        int padding = rowTemplate.padding;
        row.setLayoutParams(mTableRowLayoutParams);
        for (Map.Entry<String, TableRow.LayoutParams> entry : listHeader.entrySet()) {
            String key = entry.getKey();
            TableRow.LayoutParams value = entry.getValue();
            TextView mTextView = new TextView(mContext);
            mTextView.setTypeface(null, Typeface.BOLD);
            mTextView.setTextColor(HEADER_TEXT_COLOR);
            mTextView.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.table_border));
            mTextView.setLayoutParams(value);
            mTextView.setPadding(padding, padding, padding, padding);
            mTextView.setText(key);
            row.addView(mTextView);
        }
        row.startAnimation(AnimationUtils.loadAnimation(mContext, android.R.anim.fade_in));
        parentLayout.addView(row);
        return this;
    }
}
